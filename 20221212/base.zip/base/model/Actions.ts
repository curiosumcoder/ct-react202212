enum Actions {
  Read,
  Create,
  Edit,
  Delete
}

// const Actions = {
//   Read: 0,
//   Create: 1,
//   Edit: 2,
//   Delete: 3,
// } as const;

export default Actions;
