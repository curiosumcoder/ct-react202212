import React from 'react'

function NotFound404() {
  return (
    <div>NotFound404</div>
  )
}

export default NotFound404