import React from 'react'

function Error500() {
  return (
    <div>Error500</div>
  )
}

export default Error500