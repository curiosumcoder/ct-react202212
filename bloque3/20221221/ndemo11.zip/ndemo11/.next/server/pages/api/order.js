"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/order";
exports.ids = ["pages/api/order"];
exports.modules = {

/***/ "(api)/./pages/api/order.ts":
/*!****************************!*\
  !*** ./pages/api/order.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\nasync function handler(req, res) {\n    const { method , body  } = req;\n    switch(method){\n        case \"POST\":\n            // Save data on database\n            console.log(body);\n            res.status(200).end();\n            break;\n        default:\n            res.setHeader(\"Allow\", [\n                \"POST\"\n            ]);\n            res.status(405).end(`Method ${method} Not Allowed`);\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvb3JkZXIudHMuanMiLCJtYXBwaW5ncyI6Ijs7OztBQUllLGVBQWVBLFFBQzVCQyxHQUFtQixFQUNuQkMsR0FBcUMsRUFDckM7SUFDQSxNQUFNLEVBQUNDLE9BQU0sRUFBRUMsS0FBSSxFQUFDLEdBQUdIO0lBRXZCLE9BQVFFO1FBQ04sS0FBSztZQUNILHdCQUF3QjtZQUN4QkUsUUFBUUMsR0FBRyxDQUFDRjtZQUNaRixJQUFJSyxNQUFNLENBQUMsS0FBS0MsR0FBRztZQUNuQixLQUFNO1FBQ1I7WUFDRU4sSUFBSU8sU0FBUyxDQUFDLFNBQVM7Z0JBQUM7YUFBTztZQUMvQlAsSUFBSUssTUFBTSxDQUFDLEtBQUtDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sRUFBRUwsT0FBTyxZQUFZLENBQUM7SUFDdEQ7QUFDRixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbmRlbW8xMS8uL3BhZ2VzL2FwaS9vcmRlci50cz9jY2JjIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgTmV4dEFwaVJlcXVlc3QsIE5leHRBcGlSZXNwb25zZSB9IGZyb20gJ25leHQnO1xyXG5pbXBvcnQgSVByb2R1Y3QgZnJvbSAnLi4vLi4vbW9kZWwvcHJvZHVjdC9JUHJvZHVjdCc7XHJcbmltcG9ydCBzcWxpdGUzIGZyb20gJ3NxbGl0ZTMnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24gaGFuZGxlcihcclxuICByZXE6IE5leHRBcGlSZXF1ZXN0LFxyXG4gIHJlczogTmV4dEFwaVJlc3BvbnNlPEFycmF5PElQcm9kdWN0Pj5cclxuKSB7XHJcbiAgY29uc3Qge21ldGhvZCwgYm9keX0gPSByZXE7XHJcblxyXG4gIHN3aXRjaCAobWV0aG9kKSB7XHJcbiAgICBjYXNlICdQT1NUJzpcclxuICAgICAgLy8gU2F2ZSBkYXRhIG9uIGRhdGFiYXNlXHJcbiAgICAgIGNvbnNvbGUubG9nKGJvZHkpXHJcbiAgICAgIHJlcy5zdGF0dXMoMjAwKS5lbmQoKTtcclxuICAgICAgYnJlYWs7XHJcbiAgICBkZWZhdWx0OlxyXG4gICAgICByZXMuc2V0SGVhZGVyKCdBbGxvdycsIFsnUE9TVCddKTtcclxuICAgICAgcmVzLnN0YXR1cyg0MDUpLmVuZChgTWV0aG9kICR7bWV0aG9kfSBOb3QgQWxsb3dlZGApO1xyXG4gIH1cclxufVxyXG4iXSwibmFtZXMiOlsiaGFuZGxlciIsInJlcSIsInJlcyIsIm1ldGhvZCIsImJvZHkiLCJjb25zb2xlIiwibG9nIiwic3RhdHVzIiwiZW5kIiwic2V0SGVhZGVyIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./pages/api/order.ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/order.ts"));
module.exports = __webpack_exports__;

})();