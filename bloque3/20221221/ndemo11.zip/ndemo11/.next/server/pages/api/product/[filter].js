"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/product/[filter]";
exports.ids = ["pages/api/product/[filter]"];
exports.modules = {

/***/ "sqlite3":
/*!**************************!*\
  !*** external "sqlite3" ***!
  \**************************/
/***/ ((module) => {

module.exports = require("sqlite3");

/***/ }),

/***/ "(api)/./pages/api/product/[filter].ts":
/*!***************************************!*\
  !*** ./pages/api/product/[filter].ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var sqlite3__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sqlite3 */ \"sqlite3\");\n/* harmony import */ var sqlite3__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sqlite3__WEBPACK_IMPORTED_MODULE_0__);\n\nconst queryDB = (filter)=>new Promise((resolve, reject)=>{\n        let result = Array();\n        let db = new (sqlite3__WEBPACK_IMPORTED_MODULE_0___default().Database)(\"./data/Northwind.db\");\n        let sql = `SELECT ProductID, ProductName, SupplierID, CategoryID, QuantityPerUnit, UnitPrice, UnitsInStock, UnitsOnOrder, ReorderLevel, Discontinued\r\nFROM Products WHERE ProductName LIKE ?;`;\n        filter = `%${filter}%`;\n        console.log(`Quering with filter ${filter} ...`);\n        db.all(sql, [\n            filter\n        ], (err, rows)=>{\n            if (err) {\n                reject(err);\n            }\n            rows.forEach((row)=>{\n                const { ProductID: id , ProductName: productName , UnitPrice: unitPrice , QuantityPerUnit: quantityPerUnit  } = row;\n                const p = {\n                    id,\n                    productName,\n                    unitPrice,\n                    quantityPerUnit\n                };\n                result = [\n                    p,\n                    ...result\n                ];\n            });\n            resolve(result);\n        });\n        // close the database connection\n        db.close();\n    });\nasync function handler(req, res) {\n    const { query: { filter  } , method  } = req;\n    switch(method){\n        case \"GET\":\n            // Get data from your database\n            if (filter) {\n                console.log(`Searching for ${filter} ...`);\n                const data = await queryDB(filter);\n                console.log(data);\n                res.status(200).json(data);\n            } else {\n                res.status(200);\n            }\n            break;\n        default:\n            res.setHeader(\"Allow\", [\n                \"GET\"\n            ]);\n            res.status(405).end(`Method ${method} Not Allowed`);\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvcHJvZHVjdC9bZmlsdGVyXS50cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFFOEI7QUFFOUIsTUFBTUMsVUFBVSxDQUFDQyxTQUNmLElBQUlDLFFBQXlCLENBQUNDLFNBQVNDLFNBQVc7UUFDaEQsSUFBSUMsU0FBU0M7UUFFYixJQUFJQyxLQUFLLElBQUlSLHlEQUFnQixDQUFDO1FBRTlCLElBQUlVLE1BQU0sQ0FBQztRQUdYUixTQUFTLENBQUMsQ0FBQyxFQUFFQSxPQUFPLENBQUMsQ0FBQztRQUN0QlMsUUFBUUMsR0FBRyxDQUFDLENBQUM7UUFDYkosR0FBR0ssR0FBRyxDQUFDSCxLQUFLO1lBQUNSO1NBQU8sRUFBRSxDQUFDWSxLQUFVQztZQUMvQixJQUFJRCxLQUFLO2dCQUNQVDtZQUNGLENBQUM7WUFFRFU7Z0JBQ0UsTUFBTSxFQUNKRztnQkFLRixNQUFNUSxJQUFJO29CQUFFUDtvQkFBSUU7b0JBQWFFO29CQUFXRTtnQkFBZ0I7Z0JBQ3hEbkI7b0JBQVVvQjs7aUJBQWE7WUFDekI7WUFFQXRCO1FBQ0Y7UUFFQTtRQUNBSSxHQUFHbUIsS0FBSztJQUNWO0FBRUY7QUFLSUksSUFBTyxFQUFFN0IsT0FBTSxFQUFFLEdBQ2pCOEIsT0FBTSxFQUNQLEdBQUdIO0lBRUosT0FBUUc7UUFDTixLQUFLO1lBQ0g7WUFDQSxJQUFJOUIsUUFBUTtnQkFDVlMsUUFBUUM7Z0JBQ1IsTUFBTXFCLE9BQU8sTUFBTWhDLFFBQVFDO2dCQUMzQlMsUUFBUUMsR0FBRyxDQUFDcUI7Z0JBQ1pILElBQUlJLE1BQU0sQ0FBQyxLQUFLQztZQUNsQixPQUFPO2dCQUNMTCxJQUFJSTtZQUNOLENBQUM7WUFDRDtRQUNGO1lBQ0VKLElBQUlNO2dCQUFvQjthQUFNO1lBQzlCTjtJQUNKO0FBQ0YsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL25kZW1vMTEvLi9wYWdlcy9hcGkvcHJvZHVjdC9bZmlsdGVyXS50cz80ZTAwIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgTmV4dEFwaVJlcXVlc3QsIE5leHRBcGlSZXNwb25zZSB9IGZyb20gJ25leHQnO1xyXG5pbXBvcnQgSVByb2R1Y3QgZnJvbSAnLi4vLi4vLi4vbW9kZWwvcHJvZHVjdC9JUHJvZHVjdCc7XHJcbmltcG9ydCBzcWxpdGUzIGZyb20gJ3NxbGl0ZTMnO1xyXG5cclxuY29uc3QgcXVlcnlEQiA9IChmaWx0ZXI6IHN0cmluZykgPT5cclxuICBuZXcgUHJvbWlzZTxBcnJheTxJUHJvZHVjdD4+KChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgIGxldCByZXN1bHQgPSBBcnJheTxJUHJvZHVjdD4oKTtcclxuXHJcbiAgICBsZXQgZGIgPSBuZXcgc3FsaXRlMy5EYXRhYmFzZSgnLi9kYXRhL05vcnRod2luZC5kYicpO1xyXG5cclxuICAgIGxldCBzcWwgPSBgU0VMRUNUIFByb2R1Y3RJRCwgUHJvZHVjdE5hbWUsIFN1cHBsaWVySUQsIENhdGVnb3J5SUQsIFF1YW50aXR5UGVyVW5pdCwgVW5pdFByaWNlLCBVbml0c0luU3RvY2ssIFVuaXRzT25PcmRlciwgUmVvcmRlckxldmVsLCBEaXNjb250aW51ZWRcclxuRlJPTSBQcm9kdWN0cyBXSEVSRSBQcm9kdWN0TmFtZSBMSUtFID87YDtcclxuXHJcbiAgICBmaWx0ZXIgPSBgJSR7ZmlsdGVyfSVgO1xyXG4gICAgY29uc29sZS5sb2coYFF1ZXJpbmcgd2l0aCBmaWx0ZXIgJHtmaWx0ZXJ9IC4uLmApO1xyXG4gICAgZGIuYWxsKHNxbCwgW2ZpbHRlcl0sIChlcnI6IGFueSwgcm93czogYW55KSA9PiB7XHJcbiAgICAgIGlmIChlcnIpIHtcclxuICAgICAgICByZWplY3QoZXJyKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgcm93cy5mb3JFYWNoKChyb3c6IGFueSkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHtcclxuICAgICAgICAgIFByb2R1Y3RJRDogaWQsXHJcbiAgICAgICAgICBQcm9kdWN0TmFtZTogcHJvZHVjdE5hbWUsXHJcbiAgICAgICAgICBVbml0UHJpY2U6IHVuaXRQcmljZSxcclxuICAgICAgICAgIFF1YW50aXR5UGVyVW5pdDogcXVhbnRpdHlQZXJVbml0LFxyXG4gICAgICAgIH0gPSByb3c7XHJcbiAgICAgICAgY29uc3QgcCA9IHsgaWQsIHByb2R1Y3ROYW1lLCB1bml0UHJpY2UsIHF1YW50aXR5UGVyVW5pdCB9O1xyXG4gICAgICAgIHJlc3VsdCA9IFtwLCAuLi5yZXN1bHRdO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHJlc29sdmUocmVzdWx0KTtcclxuICAgIH0pO1xyXG5cclxuICAgIC8vIGNsb3NlIHRoZSBkYXRhYmFzZSBjb25uZWN0aW9uXHJcbiAgICBkYi5jbG9zZSgpO1xyXG4gIH0pO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24gaGFuZGxlcihcclxuICByZXE6IE5leHRBcGlSZXF1ZXN0LFxyXG4gIHJlczogTmV4dEFwaVJlc3BvbnNlPEFycmF5PElQcm9kdWN0Pj5cclxuKSB7XHJcbiAgY29uc3Qge1xyXG4gICAgcXVlcnk6IHsgZmlsdGVyIH0sXHJcbiAgICBtZXRob2QsXHJcbiAgfSA9IHJlcTtcclxuXHJcbiAgc3dpdGNoIChtZXRob2QpIHtcclxuICAgIGNhc2UgJ0dFVCc6XHJcbiAgICAgIC8vIEdldCBkYXRhIGZyb20geW91ciBkYXRhYmFzZVxyXG4gICAgICBpZiAoZmlsdGVyKSB7XHJcbiAgICAgICAgY29uc29sZS5sb2coYFNlYXJjaGluZyBmb3IgJHtmaWx0ZXJ9IC4uLmApO1xyXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBxdWVyeURCKGZpbHRlcik7XHJcbiAgICAgICAgY29uc29sZS5sb2coZGF0YSk7XHJcbiAgICAgICAgcmVzLnN0YXR1cygyMDApLmpzb24oZGF0YSk7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmVzLnN0YXR1cygyMDApO1xyXG4gICAgICB9XHJcbiAgICAgIGJyZWFrO1xyXG4gICAgZGVmYXVsdDpcclxuICAgICAgcmVzLnNldEhlYWRlcignQWxsb3cnLCBbJ0dFVCddKTtcclxuICAgICAgcmVzLnN0YXR1cyg0MDUpLmVuZChgTWV0aG9kICR7bWV0aG9kfSBOb3QgQWxsb3dlZGApO1xyXG4gIH1cclxufVxyXG4iXSwibmFtZXMiOlsic3FsaXRlMyIsInF1ZXJ5REIiLCJmaWx0ZXIiLCJQcm9taXNlIiwicmVzb2x2ZSIsInJlamVjdCIsInJlc3VsdCIsIkFycmF5IiwiZGIiLCJEYXRhYmFzZSIsInNxbCIsImNvbnNvbGUiLCJsb2ciLCJhbGwiLCJlcnIiLCJyb3dzIiwiZm9yRWFjaCIsInJvdyIsIlByb2R1Y3RJRCIsImlkIiwiUHJvZHVjdE5hbWUiLCJwcm9kdWN0TmFtZSIsIlVuaXRQcmljZSIsInVuaXRQcmljZSIsIlF1YW50aXR5UGVyVW5pdCIsInF1YW50aXR5UGVyVW5pdCIsInAiLCJjbG9zZSIsImhhbmRsZXIiLCJyZXEiLCJyZXMiLCJxdWVyeSIsIm1ldGhvZCIsImRhdGEiLCJzdGF0dXMiLCJqc29uIiwic2V0SGVhZGVyIiwiZW5kIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./pages/api/product/[filter].ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/product/[filter].ts"));
module.exports = __webpack_exports__;

})();