enum Actions {
  Search,
  Detail,
  Create,
  Edit,
  Delete
}

export default Actions;
